import matplotlib.pyplot as plt
import cv2
import numpy as np

# Load the images
house1_img = cv2.imread('House1.jpg', cv2.IMREAD_GRAYSCALE)
house2_img = cv2.imread('House2.jpg', cv2.IMREAD_GRAYSCALE)

# Apply the convolution filter using the filter2D function from OpenCV
def myImageFilter(input_image, kernel):
    # The function uses a border type that reflects the border elements of the image
    result_image = cv2.filter2D(input_image, -1, kernel, borderType=cv2.BORDER_REFLECT)
    return result_image


# Define the kernels
averaging_kernel_3x3 = np.ones((3, 3), np.float32) / 9
averaging_kernel_5x5 = np.ones((5, 5), np.float32) / 25
sobel_kernel_x = np.array([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]])
sobel_kernel_y = np.array([[-1, -2, -1], [0, 0, 0], [1, 2, 1]])
prewitt_kernel_x = np.array([[-1, 0, 1], [-1, 0, 1], [-1, 0, 1]])
prewitt_kernel_y = np.array([[-1, -1, -1], [0, 0, 0], [1, 1, 1]])

# Function to generate Gaussian kernel
def gaussian_kernel(size, sigma=1):
    size = int(size) // 2 * 2 + 1  # Ensure odd size for symmetry
    x, y = np.mgrid[-size//2:size//2+1, -size//2:size//2+1]
    normal = 1 / (2.0 * np.pi * sigma**2)
    g = np.exp(-((x**2 + y**2) / (2.0*sigma**2))) * normal
    return g

# Function to display images
def display_images(original, filtered, title1='Original', title2='Filtered'):
    plt.figure(figsize=(10, 5))
    plt.subplot(1, 2, 1)
    plt.imshow(original, cmap='gray')
    plt.title(title1)
    plt.axis('off')
    
    plt.subplot(1, 2, 2)
    plt.imshow(filtered, cmap='gray')
    plt.title(title2)
    plt.axis('off')
    
    plt.show()

# Apply 3x3 averaging filter to House1 and display
house1_avg_3x3 = myImageFilter(house1_img, averaging_kernel_3x3)
house1_avg_3x3_normalized = cv2.normalize(house1_avg_3x3, None, 0, 255, cv2.NORM_MINMAX)

display_images(house1_img, house1_avg_3x3_normalized, 'House1 Original', 'House1 with 3x3 Averaging')

# Apply 5x5 averaging filter to House1 and display
house1_avg_5x5 = myImageFilter(house1_img, averaging_kernel_5x5)
house1_avg_5x5_normalized = cv2.normalize(house1_avg_5x5, None, 0, 255, cv2.NORM_MINMAX)

display_images(house1_img, house1_avg_5x5_normalized, 'House1 Original', 'House1 with 5x5 Averaging')


# Apply 3x3 averaging filter to House2 and display
house2_avg_3x3 = myImageFilter(house2_img, averaging_kernel_3x3)
house2_avg_3x3_normalized = cv2.normalize(house2_avg_3x3, None, 0, 255, cv2.NORM_MINMAX)

display_images(house2_img, house2_avg_3x3_normalized, 'House2 Original', 'House2 with 3x3 Averaging')

# Apply 5x5 averaging filter to House2 and display
house2_avg_5x5 = myImageFilter(house2_img, averaging_kernel_5x5)
house2_avg_5x5_normalized = cv2.normalize(house2_avg_5x5, None, 0, 255, cv2.NORM_MINMAX)
display_images(house2_img, house2_avg_5x5_normalized, 'House2 Original', 'House2 with 5x5 Averaging')



# Function to display images with Gaussian kernel heatmap
def display1(original, filtered, kernel, title1='Original', title2='Filtered', title3='Kernel'):
    plt.figure(figsize=(15, 5)) 
    plt.subplot(1, 3, 1)
    plt.imshow(original, cmap='gray')
    plt.title(title1)
    plt.axis('off')
    
    plt.subplot(1, 3, 2)
    plt.imshow(filtered, cmap='gray')
    plt.title(title2)
    plt.axis('off')

    plt.subplot(1, 3, 3)
    plt.imshow(kernel, cmap='hot') 
    plt.title(title3)
    plt.axis('off')
    
    plt.show()

# Apply Gaussian filter with sigma=1, 2, 3 to House1 and House 2 and display
sigmas = [1, 2, 3]
for sigma in sigmas:
    # (6*sigma + 1) x (6*sigma + 1) kernel
    size = int(2*np.ceil(2*sigma)+1) 
    gaussian_kernel_sigma = gaussian_kernel(size, sigma)
    house1_gaussian = myImageFilter(house1_img, gaussian_kernel_sigma)
    house1_gaussian_normalized = cv2.normalize(house1_gaussian, None, 0, 255, cv2.NORM_MINMAX)
    display1(house1_img, house1_gaussian_normalized, gaussian_kernel_sigma, 'House1 Original', f'House1 with Gaussian σ={sigma}', f'Gaussian Kernel σ={sigma}')

for sigma in sigmas:
    size = int(2*np.ceil(2*sigma)+1) 
    gaussian_kernel_sigma = gaussian_kernel(size, sigma)
    house2_gaussian = myImageFilter(house2_img, gaussian_kernel_sigma)
    house2_gaussian_normalized = cv2.normalize(house2_gaussian, None, 0, 255, cv2.NORM_MINMAX)
    display1(house2_img, house2_gaussian_normalized, gaussian_kernel_sigma, 'House2 Original', f'House2 with Gaussian σ={sigma}', f'Gaussian Kernel σ={sigma}')



# Function to display four images side by side
def display_four_images(img1, img2, img3, img4, title1='Image 1', title2='Image 2', title3='Image 3', title4='Image 4'):
    plt.figure(figsize=(20, 10))  # Adjust the size to fit four images
    plt.subplot(1, 4, 1)
    plt.imshow(img1, cmap='gray')
    plt.title(title1)
    plt.axis('off')
    
    plt.subplot(1, 4, 2)
    plt.imshow(img2, cmap='gray')
    plt.title(title2)
    plt.axis('off')

    plt.subplot(1, 4, 3)
    plt.imshow(img3, cmap='gray')
    plt.title(title3)
    plt.axis('off')

    plt.subplot(1, 4, 4)
    plt.imshow(img4, cmap='gray')
    plt.title(title4)
    plt.axis('off')
    
    plt.show()
    
    
def normalize_and_clip_image(image):
    if image.size == 0:
        return image

    image = image - image.min()
    image = image / image.max()
    image = (image * 255).astype(np.uint8)
    return image


# Function to apply edge detection
def apply_edge_detection(input_image, kernel_x, kernel_y, title):
    edge_x = myImageFilter(input_image, kernel_x)
    edge_y = myImageFilter(input_image, kernel_y)
    edge_combined = np.hypot(edge_x, edge_y)
    edge_combined = normalize_and_clip_image(edge_combined)
    display_four_images(input_image, edge_x, edge_y, edge_combined,
                         f'{title} Original', f'{title} Edge X', f'{title} Edge Y', f'{title} Edge Combined')
    
    
apply_edge_detection(house1_img, sobel_kernel_x, sobel_kernel_y, 'House1 Sobel')
apply_edge_detection(house2_img, sobel_kernel_x, sobel_kernel_y, 'House2 Sobel')
apply_edge_detection(house1_img, prewitt_kernel_x, prewitt_kernel_y, 'House1 Prewitt')
apply_edge_detection(house2_img, prewitt_kernel_x, prewitt_kernel_y, 'House2 Prewitt')
# Apply Sobel and Prewitt filters on normalized images
house1_sobel_x = myImageFilter(house1_img, sobel_kernel_x)
house1_sobel_y = myImageFilter(house1_img, sobel_kernel_y)
house2_sobel_x = myImageFilter(house2_img, sobel_kernel_x)
house2_sobel_y = myImageFilter(house2_img, sobel_kernel_y)

# Apply Prewitt edge detection to House1 and display
house1_prewitt_x = myImageFilter(house1_img, prewitt_kernel_x)
house1_prewitt_y = myImageFilter(house1_img, prewitt_kernel_y)
house2_prewitt_x = myImageFilter(house2_img, prewitt_kernel_x)
house2_prewitt_y = myImageFilter(house2_img, prewitt_kernel_y)

# Calculate the gradient magnitude for Sobel
house1_sobel_combined = np.sqrt(house1_sobel_x**2 + house1_sobel_y**2)
house2_sobel_combined = np.sqrt(house2_sobel_x**2 + house2_sobel_y**2)

# Calculate the gradient magnitude for Prewitt
house1_prewitt_combined = np.sqrt(house1_prewitt_x**2 + house1_prewitt_y**2)
house2_prewitt_combined = np.sqrt(house2_prewitt_x**2 + house2_prewitt_y**2)

# Normalize the images
house1_sobel_x_normalized = cv2.normalize(house1_sobel_x, None, 0, 255, cv2.NORM_MINMAX)
house1_sobel_y_normalized = cv2.normalize(house1_sobel_y, None, 0, 255, cv2.NORM_MINMAX)
house1_sobel_combined_normalized = cv2.normalize(house1_sobel_combined, None, 0, 255, cv2.NORM_MINMAX)

house1_prewitt_x_normalized = cv2.normalize(house1_prewitt_x, None, 0, 255, cv2.NORM_MINMAX)
house1_prewitt_y_normalized = cv2.normalize(house1_prewitt_y, None, 0, 255, cv2.NORM_MINMAX)
house1_prewitt_combined_normalized = cv2.normalize(house1_prewitt_combined, None, 0, 255, cv2.NORM_MINMAX)

house2_sobel_x_normalized = cv2.normalize(house2_sobel_x, None, 0, 255, cv2.NORM_MINMAX)
house2_sobel_y_normalized = cv2.normalize(house2_sobel_y, None, 0, 255, cv2.NORM_MINMAX)
house2_sobel_combined_normalized = cv2.normalize(house2_sobel_combined, None, 0, 255, cv2.NORM_MINMAX)

house2_prewitt_x_normalized = cv2.normalize(house2_prewitt_x, None, 0, 255, cv2.NORM_MINMAX)
house2_prewitt_y_normalized = cv2.normalize(house2_prewitt_y, None, 0, 255, cv2.NORM_MINMAX)
house2_prewitt_combined_normalized = cv2.normalize(house2_prewitt_combined, None, 0, 255, cv2.NORM_MINMAX)

# Display Sobel results for img1
display_four_images(house1_img, house1_sobel_x_normalized, house1_sobel_y_normalized, house1_sobel_combined_normalized, 'House1 Original', 'House1 Sobel X', 'House1 Sobel Y', 'House1 Sobel Combined')

# Display Prewitt results  for img1
display_four_images(house1_img, house1_prewitt_x_normalized, house1_prewitt_y_normalized, house1_prewitt_combined_normalized, 'House1 Original', 'House1 Prewitt X', 'House1 Prewitt Y', 'House1 Prewitt Combined')

# Display Sobel results  for img2
display_four_images(house2_img, house2_sobel_x_normalized, house2_sobel_y_normalized, house2_sobel_combined_normalized, 'House2 Original', 'House2 Sobel X', 'House2 Sobel Y', 'House2 Sobel Combined')

# Display Prewitt results  for img2
display_four_images(house2_img, house1_prewitt_x_normalized, house2_prewitt_y_normalized, house2_prewitt_combined_normalized, 'House2 Original', 'House2 Prewitt X', 'House2 Prewitt Y', 'House2 Prewitt Combined')
