import cv2
import numpy as np
import matplotlib.pyplot as plt

# Load the images 
walk_1_path = 'walk_1.jpg'
walk_2_path = 'walk_2.jpg'

# Check if the files exist and read them
try:
    walk_1 = cv2.imread(walk_1_path)
    walk_2 = cv2.imread(walk_2_path)
    if walk_1 is None or walk_2 is None:
        raise ValueError("One of the images didn't load correctly. Check the file paths.")
except Exception as e:
    error_message = str(e)

# If images are loaded successfully
if 'error_message' not in locals():
    # Convert images to grayscale
    walk_1_gray = cv2.cvtColor(walk_1, cv2.COLOR_BGR2GRAY)
    walk_2_gray = cv2.cvtColor(walk_2, cv2.COLOR_BGR2GRAY)

    # Ensure the images have the same size
    walk_2_gray = cv2.resize(walk_2_gray, (walk_1_gray.shape[1], walk_1_gray.shape[0]))

    # Subtract walk_2.jpg from walk_1.jpg
    result = cv2.absdiff(walk_1_gray, walk_2_gray)

    # Normalize the result to ensure visibility
    result_normalized = cv2.normalize(result, None, 0, 255, cv2.NORM_MINMAX)

    # Create a gray background image with the same size as the result
    background = np.full_like(result_normalized, 200, dtype=np.uint8)  

    # Combine the subtracted result with the background
    result_with_background = cv2.addWeighted(result_normalized, 1, background, 0.7, 0.9)

    # Prepare to show the images using matplotlib
    images_to_show = {
        'Walk 1': walk_1_gray,
        'Walk 2': walk_2_gray,
        'Subtraction Result': result_with_background
    }
else:
    images_to_show = {'Error': error_message}

# Display the images using matplotlib
plt.figure(figsize=(15, 5))
for i, (title, img) in enumerate(images_to_show.items()):
    plt.subplot(1, len(images_to_show), i + 1)
    plt.imshow(img, cmap='gray')
    plt.title(title)
    plt.axis('off')
plt.tight_layout()
plt.show()


