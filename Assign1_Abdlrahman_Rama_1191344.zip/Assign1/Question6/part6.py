import cv2
import matplotlib.pyplot as plt

# Load the image in grayscale
image1 = cv2.imread('Q_4.jpg', cv2.IMREAD_GRAYSCALE)

# Test different values of 'Threshold'
threshold_values = [50, 100, 150, 200, 250, 300, 350, 400]

# Create subplots for better display
rows, cols = 2, 4
plt.figure(figsize=(20, 10))

# Display the original image
plt.subplot(rows, cols, 1)
plt.imshow(image1, cmap='gray')
plt.title('Original Image')

# Apply Canny edge detector for different thresholds
for i, threshold in enumerate(threshold_values):
    edges = cv2.Canny(image1, threshold, 2 * threshold)
    
    # Display the result
    plt.subplot(rows, cols, i + 2 if i < 7 else 8)
    plt.imshow(edges, cmap='gray')
    plt.title(f'Threshold = {threshold}')

# Show the plots
plt.tight_layout()
plt.show()
