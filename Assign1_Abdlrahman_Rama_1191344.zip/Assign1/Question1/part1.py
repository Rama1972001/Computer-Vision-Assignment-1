from skimage import data, img_as_ubyte
import matplotlib.pyplot as plt
from skimage.transform import resize
import cv2
from skimage.util import random_noise
import numpy as np
# Load an example grayscale image
woman_img = cv2.imread('img.jpg', cv2.IMREAD_GRAYSCALE)

# Resize the woman image to 256x256 pixels
woman_img_resized = resize(woman_img, (256, 256), anti_aliasing=True)

# Convert the woman image to 8-bit
woman_image = img_as_ubyte(woman_img_resized)

# Load another example grayscale image
astronaut_img = data.astronaut()

# Convert the astronaut image to grayscale
astronaut_img_gray = cv2.cvtColor(astronaut_img, cv2.COLOR_RGB2GRAY)

# Resize the astronaut image to 256x256 pixels
astronaut_img_resized = resize(astronaut_img_gray, (256, 256), anti_aliasing=True)

# Convert the astronaut image to 8-bit
astronaut_image = img_as_ubyte(astronaut_img_resized)

# Display the images side by side
plt.figure(figsize=(12, 6))

plt.subplot(1, 2, 1)
plt.imshow(woman_image, cmap='gray')
plt.title('Original 8-bit Gray-Level Woman Image (256x256)')
plt.axis('off')

plt.subplot(1, 2, 2)
plt.imshow(astronaut_image, cmap='gray')
plt.title('Resized 8-bit Gray-Level Astronaut Image (256x256)')
plt.axis('off')

plt.show()


# Apply power-law transformation with gamma=0.4
gamma = 0.4
transformed_woman_image = np.power(woman_image / 255.0, gamma) * 255.0
transformed_woman_image = np.uint8(transformed_woman_image)
transformed_astronaut_image = np.power(astronaut_image / 255.0, gamma) * 255.0
transformed_astronaut_image = np.uint8(transformed_astronaut_image)

# Display the original and transformed woman images side by side
plt.figure(figsize=(14, 7))

plt.subplot(1, 2, 1)
plt.title('Original Woman Image')
plt.imshow(woman_image, cmap='gray')
plt.axis('off')

plt.subplot(1, 2, 2)
plt.title('Transformed Woman Image (Gamma=0.4)')
plt.imshow(transformed_woman_image, cmap='gray')
plt.axis('off')

plt.show()

# Display the original and transformed astronaut images side by side
plt.figure(figsize=(14, 7))

plt.subplot(1, 2, 1)
plt.title('Original Astronaut Image')
plt.imshow(astronaut_image, cmap='gray')
plt.axis('off')

plt.subplot(1, 2, 2)
plt.title('Transformed Astronaut Image (Gamma=0.4)')
plt.imshow(transformed_astronaut_image, cmap='gray')
plt.axis('off')

plt.show()




# Zero-mean Gaussian noise with a variance of 40 to the original image

# Normalizing the variance because the image is 8-bit
variance = 40 / 255  

#Add random noise ,the mode is set to 'gaussian', indicating that Gaussian noise will be applied.
gaussian_noise_woman_image = random_noise(woman_image, mode='gaussian', var=variance)
gaussian_noise_astronaut_image = random_noise(astronaut_image, mode='gaussian', var=variance)


plt.figure(figsize=(12, 6))

plt.subplot(1, 2, 1)
plt.imshow(gaussian_noise_woman_image, cmap='gray')
plt.title('Woman Image with Gaussian Noise (Variance=40)')
plt.axis('off')
plt.subplot(1, 2, 2)
plt.imshow(gaussian_noise_astronaut_image, cmap='gray')
plt.title('Astronaut Image with Gaussian Noise (Variance=40)')
plt.axis('off')
plt.show()




# Apply a 5x5 mean filter to the noisy woman image
mean_filtered_woman_image = cv2.blur(gaussian_noise_woman_image, (5, 5))

# Apply a 5x5 mean filter to the noisy astronaut image
mean_filtered_astronaut_image = cv2.blur(gaussian_noise_astronaut_image, (5, 5))


# Display the images
plt.figure(figsize=(12, 8))

plt.subplot(2, 3, 1)
plt.imshow(gaussian_noise_woman_image, cmap='gray')
plt.title('Noisy Woman Image (Variance=40)')
plt.axis('off')

plt.subplot(2, 3, 2)
plt.imshow(mean_filtered_woman_image, cmap='gray')
plt.title('Mean Filtered Woman Image')
plt.axis('off')

plt.subplot(2, 3, 3)
plt.imshow(gaussian_noise_woman_image - mean_filtered_woman_image, cmap='gray')
plt.title('Noisy - Mean Filtered Woman')
plt.axis('off')

plt.subplot(2, 3, 4)
plt.imshow(gaussian_noise_astronaut_image, cmap='gray')
plt.title('Noisy Astronaut Image (Variance=40)')
plt.axis('off')

plt.subplot(2, 3, 5)
plt.imshow(mean_filtered_astronaut_image, cmap='gray')
plt.title('Mean Filtered Astronaut Image')
plt.axis('off')

plt.subplot(2, 3, 6)
plt.imshow(gaussian_noise_astronaut_image - mean_filtered_astronaut_image, cmap='gray')
plt.title('Noisy - Mean Filtered Astronaut')
plt.axis('off')

plt.tight_layout()
plt.show()




# Add salt and pepper noise with density=0.1
noise_density = 0.1
salt_pepper_mask = np.random.rand(*woman_image.shape) < noise_density
salt_noise = salt_pepper_mask * 255
pepper_noise = salt_pepper_mask * 0

# Applying noise to the woman image
noisy_woman_image = np.clip(woman_image + salt_noise + pepper_noise, 0, 255).astype(np.uint8)

# Applying noise to the astronaut image
salt_pepper_mask_astronaut = np.random.rand(*astronaut_image.shape) < noise_density
salt_noise_astronaut = salt_pepper_mask_astronaut * 255
pepper_noise_astronaut = salt_pepper_mask_astronaut * 0
noisy_astronaut_image = np.clip(astronaut_image + salt_noise_astronaut + pepper_noise_astronaut, 0, 255).astype(np.uint8)

# Apply a 7x7 median filter to the noisy images
median_filtered_woman_image = cv2.medianBlur(noisy_woman_image, 7)
median_filtered_astronaut_image = cv2.medianBlur(noisy_astronaut_image, 7)

# Displaying the images
plt.figure(figsize=(18, 12))

plt.subplot(2, 4, 1)
plt.title('Original Image - Woman')
plt.imshow(woman_image, cmap='gray')

plt.subplot(2, 4, 2)
plt.title('Noisy Image (Salt and Pepper) - Woman')
plt.imshow(noisy_woman_image, cmap='gray')

plt.subplot(2, 4, 3)
plt.title('Median Filter (7x7) - Woman')
plt.imshow(median_filtered_woman_image, cmap='gray')

plt.subplot(2, 4, 4)
plt.title('Difference (Noisy - Median Filtered) - Woman')
plt.imshow(noisy_woman_image - median_filtered_woman_image, cmap='gray')

plt.subplot(2, 4, 5)
plt.title('Original Image - Astronaut')
plt.imshow(astronaut_image, cmap='gray')

plt.subplot(2, 4, 6)
plt.title('Noisy Image (Salt and Pepper) - Astronaut')
plt.imshow(noisy_astronaut_image, cmap='gray')

plt.subplot(2, 4, 7)
plt.title('Median Filter (7x7) - Astronaut')
plt.imshow(median_filtered_astronaut_image, cmap='gray')

plt.subplot(2, 4, 8)
plt.title('Difference (Noisy - Median Filtered) - Astronaut')
plt.imshow(noisy_astronaut_image - median_filtered_astronaut_image, cmap='gray')

plt.tight_layout()
plt.show()




# Apply a 7x7 mean filter
mean_filter_image_1 = cv2.blur(noisy_woman_image, (7, 7))

mean_filter_image_2 = cv2.blur(noisy_astronaut_image, (7, 7))

# Displaying the images
plt.figure(figsize=(18, 12))

plt.subplot(2, 4, 1)
plt.title('Original Image - Woman')
plt.imshow(woman_image, cmap='gray')

plt.subplot(2, 4, 2)
plt.title('Noisy Image (Salt and Pepper) - Woman')
plt.imshow(noisy_woman_image, cmap='gray')

plt.subplot(2, 4, 3)
plt.title('Mean Filter (7x7) - Woman')
plt.imshow(mean_filter_image_1, cmap='gray')

plt.subplot(2, 4, 4)
plt.title('Difference (Noisy - Mean Filtered) - Woman')
plt.imshow(noisy_woman_image - mean_filter_image_1, cmap='gray')

plt.subplot(2, 4, 5)
plt.title('Original Image - Astronaut')
plt.imshow(astronaut_image, cmap='gray')

plt.subplot(2, 4, 6)
plt.title('Noisy Image (Salt and Pepper) - Astronaut')
plt.imshow(noisy_astronaut_image, cmap='gray')

plt.subplot(2, 4, 7)
plt.title('Mean Filter (7x7) - Astronaut')
plt.imshow(mean_filter_image_2, cmap='gray')

plt.subplot(2, 4, 8)
plt.title('Difference (Noisy - Mean Filtered) - Astronaut')
plt.imshow(noisy_astronaut_image - mean_filter_image_2, cmap='gray')

plt.tight_layout()
plt.show()




# Sobel kernel for horizontal and vertical edges
sobel_kernel_x = np.array([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]])
sobel_kernel_y = np.array([[-1, -2, -1], [0, 0, 0], [1, 2, 1]])

# Convolution function
def convolve(image, kernel):
    # Get the height and width of the input 
    height, width = image.shape
    
    # Get the size of the kernel
    kernel_size = len(kernel)
    
    # Initialize the output array with zeros
    output = np.zeros((height - kernel_size + 1, width - kernel_size + 1))

    # Iterate over the pixels of the output array    
    for i in range(output.shape[0]):
        for j in range(output.shape[1]):
            # Convolution operation by element-wise multiplication and summation
            output[i, j] = np.sum(image[i:i + kernel_size, j:j + kernel_size] * kernel)

    return output

# Apply Sobel filter for horizontal and vertical edges
sobel_x_woman = convolve(woman_image, sobel_kernel_x)
sobel_y_woman = convolve(woman_image, sobel_kernel_y)

sobel_x_astronaut = convolve(astronaut_image, sobel_kernel_x)
sobel_y_astronaut = convolve(astronaut_image, sobel_kernel_y)


# Combine horizontal and vertical responses
sobel_response_woman = np.sqrt(sobel_x_woman**2 + sobel_y_woman**2)

sobel_response_astronaut = np.sqrt(sobel_x_astronaut**2 + sobel_y_astronaut**2)

# Displaying the results for both images using plt.subplot
plt.figure(figsize=(18, 8))

# Display for astronaut image
plt.subplot(2, 4, 1)
plt.imshow(astronaut_image, cmap='gray')
plt.title('Original Image - Astronaut')
plt.axis('off')

plt.subplot(2, 4, 2)
plt.imshow(sobel_x_astronaut, cmap='gray')
plt.title('Sobel Gx - Astronaut')
plt.axis('off')

plt.subplot(2, 4, 3)
plt.imshow(sobel_y_astronaut, cmap='gray')
plt.title('Sobel Gy - Astronaut')
plt.axis('off')

plt.subplot(2, 4, 4)
plt.imshow(sobel_response_astronaut, cmap='gray')
plt.title('Sobel G (Gx + Gy) - Astronaut')
plt.axis('off')

# Display for woman image
plt.subplot(2, 4, 5)
plt.imshow(woman_image, cmap='gray')
plt.title('Original Image - Woman')
plt.axis('off')

plt.subplot(2, 4, 6)
plt.imshow(sobel_x_woman, cmap='gray')
plt.title('Sobel Gx - Woman')
plt.axis('off')

plt.subplot(2, 4, 7)
plt.imshow(sobel_y_woman, cmap='gray')
plt.title('Sobel Gy - Woman')
plt.axis('off')

plt.subplot(2, 4, 8)
plt.imshow(sobel_response_woman, cmap='gray')
plt.title('Sobel G (Gx + Gy) - Woman')
plt.axis('off')

plt.tight_layout()
plt.show()
