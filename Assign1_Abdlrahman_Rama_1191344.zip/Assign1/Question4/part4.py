
import cv2
import numpy as np
import matplotlib.pyplot as plt



# Load the image 
image1 = cv2.imread('Q_4.jpg', cv2.IMREAD_GRAYSCALE)

# Compute gradient magnitude using Sobel gradients
gradient_x = cv2.Sobel(image1, cv2.CV_64F, 1, 0, ksize=3)
gradient_y = cv2.Sobel(image1, cv2.CV_64F, 0, 1, ksize=3)
gradient_magnitude = np.sqrt(gradient_x**2 + gradient_y**2)

# Stretch the gradient magnitude for better visualization
gradient_magnitude_stretched = cv2.normalize(gradient_magnitude, None, 0, 255, cv2.NORM_MINMAX)


# Display the stretched gradient magnitude
plt.imshow(gradient_magnitude_stretched, cmap='gray')
plt.title('Stretched Gradient Magnitude')
plt.show()


# Compute histogram of gradient magnitude
hist, bins = np.histogram(gradient_magnitude, bins=256, range=[0, 256])

# Display histogram of gradient magnitude
plt.plot(hist)
plt.title('Histogram of Gradient Magnitude')
plt.xlabel('Gradient Magnitude')
plt.ylabel('Frequency')
plt.show()

# Compute gradient orientation
gradient_orientation = np.arctan2(gradient_y, gradient_x)

# Convert angles to the range [0, 2*pi)
gradient_orientation = (gradient_orientation + 2 * np.pi) % (2 * np.pi)

# Compute histogram of gradient orientation
hist_orientation, bins_orientation = np.histogram(gradient_orientation, bins=360, range=[0, 2*np.pi])

# Display histogram of gradient orientation
plt.plot(hist_orientation)
plt.title('Histogram of Gradient Orientation')
plt.xlabel('Gradient Orientation (radians)')
plt.ylabel('Frequency')
plt.show()
