import matplotlib.pyplot as plt
import cv2


# Read the noisy images
image1 = cv2.imread('Noisyimage1.jpg', cv2.IMREAD_GRAYSCALE)
image2 = cv2.imread('Noisyimage2.jpg', cv2.IMREAD_GRAYSCALE)

# Apply 5 by 5 Averaging filter
averaging_filtered1 = cv2.blur(image1, (5, 5))
averaging_filtered2 = cv2.blur(image2, (5, 5))

# Apply 5 by 5 Median filter
median_filtered1 = cv2.medianBlur(image1, 5)
median_filtered2 = cv2.medianBlur(image2, 5)

# Display the original and filtered images
plt.figure(figsize=(10, 8))

plt.subplot(231), plt.imshow(image1, cmap='gray'), plt.title('Original Image 1')
plt.subplot(232), plt.imshow(averaging_filtered1, cmap='gray'), plt.title('Averaging Filtered Image 1')
plt.subplot(233), plt.imshow(median_filtered1, cmap='gray'), plt.title('Median Filtered Image 1')

plt.subplot(234), plt.imshow(image2, cmap='gray'), plt.title('Original Image 2')
plt.subplot(235), plt.imshow(averaging_filtered2, cmap='gray'), plt.title('Averaging Filtered Image 2')
plt.subplot(236), plt.imshow(median_filtered2, cmap='gray'), plt.title('Median Filtered Image 2')

plt.show()